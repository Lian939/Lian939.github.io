---
layout: post
title: Plainwhite
date: 2019-05-05 09:20:00
homepage: https://github.com/thelehhman/plainwhite-jekyll
download: https://github.com/thelehhman/plainwhite-jekyll/archive/master.zip
demo: http://thelehhman.com/
author: thelehhman
thumbnail: plainwhite.png
license: MIT
license_link: https://github.com/thelehhman/plainwhite-jekyll/blob/master/LICENSE.txt
---

A portfolio-style jekyll theme for writers.

Features

- Responsive Design
- Disqus Powered Comments
- Google Analytics
- SEO