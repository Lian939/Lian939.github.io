---
layout: post
title: Texture
date: 2019-06-29 08:00:00
homepage: https://github.com/thelehhman/texture
download: https://github.com/thelehhman/texture/archive/master.zip
demo: http://thelehhman.com/texture
author: thelehhman
thumbnail: texture.png
license: MIT
license_link: https://github.com/thelehhman/texture/blob/master/LICENSE.txt
---

A configurable jekyll theme for simply beautiful blogs.

Features

- Customizable Textures
- Responsive Design
- Disqus Powered Comments
- Google Analytics
- SEO
